export class Company {
  id: String = '';
  name: String = '';
  ceo: String = '';
  summary: String = '';
  valuation: String = '';
  founder: String = '';
}
